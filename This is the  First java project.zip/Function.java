package Book;

import java.util.Scanner;


public class Function {
    int c = 0;
    Book[] x = new Book[10];

    Function() {
        for (int i = 0; i < 10; i++) {
            x[i] = new Book();
        }
    }
    
    
    public void pop() {
        if (c == x.length) { 
            System.out.println("Array is full, cannot insert at end");
        } else {
            Scanner s = new Scanner(System.in);
            x[c] = new Book();
            System.out.print("Enter ID for new end student");
            x[c].id = s.nextInt();
            c++;
        }
    }
    
    
    public void phush() {
        if (c == 0) {
            System.out.println("Array is empty, nothing to delete at end");
        } else {
            c--;
            System.out.println( x[c].id);
        }
    }

    public void peek() {
        if (c == 0) {
            System.out.println("Array is empty.");
        } else {
            for (int i = 0; i < c; i++) {
                System.out.println(x[i].id);
            }
        }
    }
    
}