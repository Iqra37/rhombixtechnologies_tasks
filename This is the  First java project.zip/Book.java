package Book;

public class Book {
int id;
String name;

}
