package Book;



import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	      Function f = new Function();
	        Scanner input = new Scanner(System.in);
	        int op;

	        do {
	            System.out.println("Choose an option:");
	            System.out.println("1. Insert At End");
	            System.out.println("2. Delete At End");
	            System.out.println("3. Display All");
	            System.out.println("4. Exit");
	            op = input.nextInt(); 

	            switch(op) {
	                case 1:
	                    System.out.println("Insert At End");
	                    f.pop();
	                    break;
	                case 2:
	                    System.out.println("Delete at end");
	                    f.phush();
	                    break;
	                    
	                case 3:
	                    System.out.println("display");
	                    f.peek();
	                    break;
	          
	                case 4:
	                    System.out.println("Exiting...");
	                    break;
	                default:
	                    System.out.println("Invalid option. Please try again.");
	                    break;
	            }
	        } while(op != 4);

	        input.close();
	    }
	}


